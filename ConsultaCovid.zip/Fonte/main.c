#include "Pesquisa.h"
//==============================================
int main(void)
{
    Loaded();
    return 0;
}
